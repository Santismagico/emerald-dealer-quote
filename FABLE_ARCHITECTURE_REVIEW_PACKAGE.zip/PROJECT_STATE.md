# PROJECT_STATE — Emerald Dealer Quote

_Actualizado: 2026-07-09 por Claude (arquitecto). Este archivo es la foto del estado real; cualquier agente debe poder continuar leyendo solo esto y los documentos que enlaza._

## Qué aplicación es

PWA de cotizaciones de joyería para Santiago (comerciante de esmeraldas, Colombia). Cotiza piezas (oro + piedras + mano de obra), genera PDF para el cliente (sin datos internos) y PDF interno (con costos y margen), comparte por WhatsApp, lleva historial, seguimiento de producción del taller y abonos del cliente. Todo local (IndexedDB), sin backend.

- **Stack:** React 19 + TypeScript + Vite 8 + Tailwind 4 + jsPDF + vite-plugin-pwa + Vitest. Sin router ni gestor de estado externo.
- **Versión:** 0.5.0 (+ función de aviso de palabras sensibles ya integrada, pendiente de tests → será v0.6.0 al cerrar el plan actual).
- **Producción:** https://santismagico.github.io/emerald-dealer-quote/ — deploy automático SOLO al hacer push a `main` (`.github/workflows/deploy.yml`).
- **Repositorio:** https://github.com/Santismagico/emerald-dealer-quote (público — nunca subir datos reales ni secretos).

## Estado de Git y respaldos

- Rama de trabajo: `fable/regeneracion-emerald-dealer-quote-v1` (sincronizada con origin).
- Punto de restauración: tag `punto-seguro-2026-07-09` (commit c3140c4), subido a GitHub.
- `main` contiene lo publicado; la rama de trabajo va adelante. **No hacer push a `main` sin autorización de Santiago** (dispara despliegue público).
- Cómo restaurar si algo sale mal: `git restore .` para descartar cambios sin commit; `git reset --hard punto-seguro-2026-07-09` para volver al punto seguro (solo si es imprescindible y avisando).

## Qué está funcionando (verificado 2026-07-09)

- `npm test`: 101 tests en verde (9 archivos).
- `npm run build`: compila sin errores.
- Todos los módulos del MVP + producción del taller + abonos (ver `PRODUCT_SPEC.md` raíz, tabla de módulos).
- Aviso de palabras sensibles antes de PDF cliente/WhatsApp: **implementado y funcionando, sin tests unitarios todavía** (`findSensitiveWordsInClientText` en `src/services/pdfContent.ts`, diálogo en `src/components/PreviewView.tsx`).

## Qué se quiere construir ahora

Cerrar los pendientes de calidad y pulido del ROADMAP v0.2/v0.2.x, en 6 etapas pequeñas definidas en `docs/EXECUTION_PLAN.md`:

1. Tests del detector de palabras sensibles (cierra trabajo ya integrado).
2. Marcado automático de cotizaciones vencidas (estado derivado, sin mutar datos).
3. Guardado eficiente en producción/abonos (guardar al cerrar/perder foco, no por tecla).
4. Recordatorio periódico de exportar respaldo.
5. Adjuntar el PDF al compartir donde el dispositivo lo soporte (Web Share API nivel 2).
6. Plantillas de piezas frecuentes.

## Decisiones tomadas (resumen; detalle en DECISIONS.md)

- Precio del oro automático: internacional 24K del día + $100.000 COP/g (D-002).
- `src/services/schema.ts` es la ÚNICA fuente de defaults/migraciones/normalización (D-010).
- Dinero en COP enteros; motor de cálculo puro; privacidad del cliente protegida por tests.
- Plan SaaS (Supabase) escrito en `SAAS_PLAN.md` pero **congelado** hasta orden de Santiago.

## Qué NO debe modificarse

- La lógica del precio del oro (`src/services/goldPrice.ts`) salvo decisión registrada.
- El motor de cálculo (`src/calc/engine.ts`) salvo bug demostrado con test.
- Los tests de privacidad (`src/services/pdfContent.test.ts`): si un cambio los rompe, el cambio está mal.
- `.github/workflows/deploy.yml` y `main` (controlan la publicación).
- No agregar dependencias sin justificarlo en `DECISIONS.md`.

## Riesgos conocidos

- Proyecto dentro de OneDrive (sincronización puede interferir con `node_modules`; conviene moverlo algún día, no urgente).
- Dependencia de 2 APIs gratuitas para el precio del oro (mitigado con fallback y límites de sanidad).
- Repo público: cuidado con datos personales en ejemplos, fixtures o capturas.
- Deuda anotada: migraciones IndexedDB versionadas — **no hacer todavía**, esperar al primer cambio real de estructura (ROADMAP).

## Siguiente paso exacto

Codex debe ejecutar la **Etapa 1** de `docs/EXECUTION_PLAN.md` (tests de `findSensitiveWordsInClientText`) siguiendo `docs/HANDOFF_TO_CODEX.md`, y actualizar este archivo al terminar cada etapa (sección "Bitácora" abajo).

## Pruebas que debe ejecutar todo agente antes de dar algo por terminado

```bash
npm test && npm run build
```

## Bitácora de etapas (Codex la actualiza)

| Fecha | Etapa | Resultado | Commit |
|---|---|---|---|
| 2026-07-09 | Preparación y protección (Claude) | Tag `punto-seguro-2026-07-09`, docs de traspaso creados | c3140c4 + siguiente |
